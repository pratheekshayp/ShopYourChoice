package com.niit.shopyourchoice.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.shopyourchoice.dao.ProductDAO;
import com.niit.shopyourchoice.entity.Product;
@EnableTransactionManagement
@Repository("productDAO")

public class ProductDAOImpl implements ProductDAO
{
@Autowired
private SessionFactory sessionFactory;

 public ProductDAOImpl(SessionFactory sessionFactory) {
	super();
	this.sessionFactory = sessionFactory;
}
@Transactional
public boolean save(Product product) {
	try 
	{
		sessionFactory.getCurrentSession().save(product);
		return true;
	} catch (Exception e) 
	{
		return false;
	}
}
@Transactional
public boolean update(Product product) {
	try
	{
		sessionFactory.getCurrentSession().update(product);
		return true;
	} catch (Exception e)
	{
	return false;
	}
}
@Transactional
public boolean delete(Product product) {
	try
	{
		sessionFactory.getCurrentSession().delete(product);
		return true;
	} catch (Exception e)
	{
	return false;
	}
}
@Transactional
public Product get(String id) {
	String hql="from Product where id="+"'"+id+"'";
 	{
 		Query query=sessionFactory.getCurrentSession().createQuery(hql);
 		List<Product>list=((ProductDAO)query).list();
 		if(list==null || list.isEmpty())
 		{
 			return null;
 		}
 		else
 		{
 			return list.get(0);
 		}
 	}
}
@Transactional

public List<Product> list()
{		
	String hql="from Product";
	Query query=sessionFactory.getCurrentSession().createQuery(hql);
	return ((ProductDAO)query).list();
}
}