package com.niit.shopyourchoice.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.shopyourchoice.dao.CategoryDAO;
import com.niit.shopyourchoice.entity.Category;

@EnableTransactionManagement
@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO 
{
	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	public CategoryDAOImpl(SessionFactory FsessionFactory) 
	{

		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public boolean save(Category category) {
		try {
			System.out.println(category);
			sessionFactory.getCurrentSession().save(category);
			return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;

		}
	}

	@Transactional
	public boolean update(Category category) {
		try {
			sessionFactory.getCurrentSession().update(category);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public boolean delete(Category category) {
		try {
			sessionFactory.getCurrentSession().delete(category);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public Category get(String id) {
		String hql = "from Category where id=" + "'" + id + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		List<Category> list = ((CategoryDAO) query).list();
		if (list == null) {
			return null;
		} else {
			return list.get(0);
		}
	}

	@Transactional

	public List<Category> list() {
		String hql = "from Category";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return ((CategoryDAO) query).list();
	}
}