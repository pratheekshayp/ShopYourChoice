package com.niit.shopyourchoice;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopyourchoice.dao.SupplierDAO;
import com.niit.shopyourchoice.entity.Supplier;

public class TestcaseSupplier {

	@Autowired 
	SupplierDAO supplierDAO;
	
	@Autowired 
	Supplier supplier;
	
	AnnotationConfigApplicationContext context;
	@Before
	public void init()
	{
	 context=new AnnotationConfigApplicationContext();
	 context.scan("com.niit.shopyourchoice");
	 context.refresh();
	 supplierDAO=(SupplierDAO) context.getBean("supplierDAO");
	 supplier=(Supplier) context.getBean("supplier");
	
	}
	
	public void deleteSupplierTestCase()
	{
		supplier.setId("PR_001");
	boolean flag=supplierDAO.delete(supplier);
	assertEquals("this not added",flag,false);
	
	}
	@Test
	public void saveSupplierTestCase()
	{
		supplier.setId("SP_003");
		supplier.setAddress("bangalore");
		
		supplier.setName("harsha electricals");
		assertEquals("addSupplierTestCase",supplierDAO.save(supplier), true);
		
	}
	
	public void listSupplierTestCase()
	{
		assertEquals("listSupplierTestCase",supplierDAO.list().size(),true);
	}

	public void updateSupplierTestCase()
	{
		supplier.setId("SP_003");
		supplier.setName("Harsha");
		
		assertEquals("updateSupplierTestCase",supplierDAO.update(supplier),true);
	}
	
	public void getSupplierTestCase()
	{
		
	}
	}


