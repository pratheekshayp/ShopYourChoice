package com.niit.shopyourchoice;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopyourchoice.dao.UserDetailsDAO;
import com.niit.shopyourchoice.entity.UserDetails;

public class TestcaseUserDetails {

	@Autowired 
	UserDetailsDAO userDetailsDAO;
	
	@Autowired 
	UserDetails userDetails;
	
	AnnotationConfigApplicationContext context;
	@Before
	public void init()
	{
	 context=new AnnotationConfigApplicationContext();
	 context.scan("com.niit.shopyourchoice");
	 context.refresh();
	 userDetailsDAO=(UserDetailsDAO) context.getBean("userDetailsDAO");
	 userDetails=(UserDetails) context.getBean("userDetails");
	
	}
	
	public void deleteUserDetailsTestCase()
	{
		userDetails.setId("PR_001");
	boolean flag=userDetailsDAO.delete(userDetails);
	assertEquals("this not added",flag,false);
	
	}
	@Test
	public void saveUserDetailsTestCase()
	{
		userDetails.setId("US_003");
		userDetails.setAddress("bangalore");
		userDetails.setContact("9611138459");
		userDetails.setMail("prathi@gmail.com");
		userDetails.setPassword("pass");
		userDetails.setName("harini");
		assertEquals("addUserDetailsTestCase",userDetailsDAO.save(userDetails), true);
		
	}
	
	public void listUserDetailsTestCase()
	{
		assertEquals("listUserDetailsTestCase",userDetailsDAO.list().size(),true);
	}

	public void updateUserDetailsTestCase()
	{
		userDetails.setId("SP_003");
		userDetails.setName("Harsha");
		
		assertEquals("updateUserDetailsTestCase",userDetailsDAO.update(userDetails),true);
	}
	
	public void getUserDetailsTestCase()
	{
		
	}
	}


