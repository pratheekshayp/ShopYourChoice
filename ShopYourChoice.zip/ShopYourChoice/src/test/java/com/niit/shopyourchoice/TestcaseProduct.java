package com.niit.shopyourchoice;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopyourchoice.dao.ProductDAO;
import com.niit.shopyourchoice.entity.Product;

public class TestcaseProduct {

	@Autowired 
	ProductDAO productDAO;
	
	@Autowired 
	Product product;
	
	AnnotationConfigApplicationContext context;
	@Before
	public void init()
	{
	 context=new AnnotationConfigApplicationContext();
	 context.scan("com.niit.shopyourchoice");
	 context.refresh();
	 productDAO=(ProductDAO) context.getBean("productDAO");
	 product=(Product) context.getBean("product");
	
	}
	
	public void deleteProductTestCase()
	{
		product.setId("PR_001");
	boolean flag=productDAO.delete(product);
	assertEquals("this not added",flag,false);
	
	}
	
	public void saveProductTestCase()
	{
		product.setId("Pr009");
		product.setDescription("this is mobile");
		product.setPrice("20000");
		product.setName("mobile");
		assertEquals("addProductTestCase",productDAO.save(product), true);
		
	}
	@Test
	public void listProductTestCase()
	{
		assertEquals("listProductTestCase",productDAO.list().size(),true);
	}

	public void updateProductTestCase()
	{
		product.setId("PR_003");
		product.setPrice("10000");
		assertEquals("updateProductTestCase",productDAO.update(product),true);
	}
	
	public void getProductTestCase()
	{
		
	}
	}


