package com.niit.shopyourchoice;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopyourchoice.dao.ProductDAO;
import com.niit.shopyourchoice.entity.Product;


public class ProductTest 
{
public static void main(String[]arg)
{
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.*");
	context.refresh();
	ProductDAO productDAO=(ProductDAO)context.getBean("productDAO");
	Product product=(Product) context.getBean("product");
	product.setId("P001");
	product.setName("apple`");
	product.setDescription("this is description");
	product.setPrice("70000");
	System.out.println(product);
	if(productDAO.save(product)==true)
			{
	System.out.println("Product created successfully");
		
			}
	else
	{
	System.out.println("not able to create the product");
		
	}
	}
	
}

