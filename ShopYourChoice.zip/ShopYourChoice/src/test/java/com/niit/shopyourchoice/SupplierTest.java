package com.niit.shopyourchoice;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopyourchoice.dao.SupplierDAO;
import com.niit.shopyourchoice.entity.Supplier;


public class SupplierTest 
{
public static void main(String[]arg)
{
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.*");
	context.refresh();
	SupplierDAO supplierDAO=(SupplierDAO)context.getBean("supplierDAO");
	Supplier supplier=(Supplier) context.getBean("supplier");
	supplier.setId("s001");
	supplier.setName("sangeetha");
	supplier.setAddress("chennai");
	System.out.println(supplier);
	if(supplierDAO.save(supplier)==true)
			{
	System.out.println("Supplier created successfully");
		
			}
	else
	{
	System.out.println("not able to create the supplier");
		
	}
	}
	
}

