package com.niit.shopyourchoice;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopyourchoice.dao.UserDetailsDAO;
import com.niit.shopyourchoice.entity.UserDetails;


public class UserDetailsTest 
{
public static void main(String[]arg)
{
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.*");
	context.refresh();
	UserDetailsDAO userDetailsDAO=(UserDetailsDAO)context.getBean("userDetailsDAO");
	UserDetails userDetails=(UserDetails) context.getBean("userDetails");
	userDetails.setId("u001");
	userDetails.setName("prathi");
	userDetails.setAddress("Mangalore");
	userDetails.setContact("9611138459");
	userDetails.setMail("pratheekshayp71@gmail.com");
	userDetails.setPassword("password");
	System.out.println(userDetails);
	if(userDetailsDAO.save(userDetails)==true)
			{
	System.out.println("UserDetails created successfully");
		
			}
	else
	{
	System.out.println("not able to create the userDetails");
		
	}
	}
	
}

