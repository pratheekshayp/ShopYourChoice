package com.niit.shopyourchoice;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopyourchoice.dao.CategoryDAO;
import com.niit.shopyourchoice.entity.Category;

public class TestcaseCategory {

	@Autowired 
	CategoryDAO categoryDAO;
	
	@Autowired 
	Category category;
	
	AnnotationConfigApplicationContext context;
	@Before
	public void init()
	{
	 context=new AnnotationConfigApplicationContext();
	 context.scan("com.niit.shopyourchoice");
	 context.refresh();
	 categoryDAO=(CategoryDAO) context.getBean("categoryDAO");
	 category=(Category) context.getBean("category");
	
	}
	
	public void deleteCategoryTestCase()
	{
		category.setId("PR_001");
	boolean flag=categoryDAO.delete(category);
	assertEquals("this not added",flag,false);
	
	}
	@Test
	public void saveCategoryTestCase()
	{
		category.setId("ct_003");
		category.setDescription("this is tv");
		
		category.setName("tv");
		assertEquals("addCategoryTestCase",categoryDAO.save(category), true);
		
	}
	
	public void listCategoryTestCase()
	{
		assertEquals("listCategoryTestCase",categoryDAO.list().size(),true);
	}

	public void updateCategoryTestCase()
	{
		category.setId("CT_003");
		category.setName("TV");
		category.setDescription("this is tv");
		assertEquals("updateCategoryTestCase",categoryDAO.update(category),true);
	}
	
	public void getCategoryTestCase()
	{
		
	}
	}


