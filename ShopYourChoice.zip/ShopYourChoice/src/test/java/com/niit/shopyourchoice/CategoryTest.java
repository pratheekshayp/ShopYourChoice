package com.niit.shopyourchoice;





import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopyourchoice.dao.CategoryDAO;
import com.niit.shopyourchoice.entity.Category;


public class CategoryTest 
{
public static void main(String[]arg)
{
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.*");
	context.refresh();
	CategoryDAO categoryDAO=(CategoryDAO)context.getBean("categoryDAO");
	Category category=(Category) context.getBean("category");
	category.setId("d444");
	category.setName("mobile");
	category.setDescription("this is description");
	System.out.println(category);
	if(categoryDAO.save(category)==true)
			{
	System.out.println("Category created successfully");
		
			}
	else
	{
	System.out.println("not able to create the category");
		
	}
	}
	
}

